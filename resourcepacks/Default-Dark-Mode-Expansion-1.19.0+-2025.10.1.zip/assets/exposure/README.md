## About the "Exposure" mod being in "Default Dark Mode: Expansion"

This is a work in progress. for now they are **Experimental** as a lot of gui assets from the mod is not 100% faithful to the Dark Mode Style yet given how complex it is-
-to make those guis stick to the Default Dark Mode style. Also, Default Dark Mode: Expansion manually updates each texture using Krita.