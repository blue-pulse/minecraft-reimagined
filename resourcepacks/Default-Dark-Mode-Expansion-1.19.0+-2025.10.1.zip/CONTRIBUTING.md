# How to Contribute to Default Dark Mode: Expansion

Thanks for wanting to help improve **Default Dark Mode: Expansion**! Follow these simple rules to keep everything consistent and awesome.

---

## Important Rules

1. **Stick to the Style**  
   - This pack keeps the **vanilla Minecraft look** with a dark mode twist.  
   - Make sure your changes fit this style.

2. **Don’t Use Automatic Tools on Mods with the Vanilla-Style GUI!**  
   - Tools like [PineTools](https://pinetools.com/darken-image) **cannot** be used for mods that aim to match Minecraft's vanilla style.
   - You **can** use these tools for mods with their own unique styles (e.g., **Cobblemon**).

3. **Use Krita for Editing**  
   - We recommend [Krita](https://krita.org/), a free and powerful tool for precise texture editing.

4. **Organize Files Properly**  
   - Place new textures in the correct folders. Match the current structure and file naming.

5. **Test Your Changes**  
   - Load the pack in Minecraft to make sure your changes work and look good.

---

## How to Submit Your Work

1. **Fork the Project**  
   - Click the "Fork" button on GitHub to make your own copy.

2. **Edit Files**  
   - Use Krita or other tools to make your changes.

3. **Test in Minecraft**  
   - Check that everything works before sharing.

4. **Submit a Pull Request**  
   - Go to your fork on GitHub and open a pull request. Write a short explanation of what you changed.

---

## Need Help?  
If you're unsure about anything, feel free to ask in the project discussions or issues tab. We're here to help!

---

Thanks again for contributing. Your work helps make this resource pack even better!
